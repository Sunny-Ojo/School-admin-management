<?php $__env->startSection('title', 'Teachers profile'); ?>
    <?php $__env->startSection('content'); ?>
    <a href="/teachers" class="btn btn-secondary mb-1">Go Back</a>
<h1 class="bg-dark text-white text-center p-2"><?php echo e($student->firstName. ' ' .$student->lastName); ?>'s Profile</h1>
<div class="card-body">
 <div class="row">
<div class="col-md-4 col-lg-4">
<img style="width:100%;height:90%" src="<?php echo e('/storage/passports/'.$student->passport); ?>" alt="Students Passport">
</div>
<div class="col-md-8 col-lg-8">
<h3>First Name:  <b><?php echo e($student->firstName); ?></b></h3>
<h3>Last Name: <b><?php echo e($student->lastName); ?></b></h3>
<h3>Date of Birth: <b><?php echo e($student->dob); ?></b></h3>
<h3>Gender: <b><?php echo e($student->gender); ?></b></h3>
<h3>Home Address: <b><?php echo e($student->homeAddress); ?></b></h3>
<h3>Father's Name: <b><?php echo e($student->fathersName); ?></b></h3>
<h3>Email Addresss: <b><?php echo e($student->emailAddress); ?></b></h3>
<h3>Phone Number: <b><?php echo e($student->phone); ?></b></h3>
<h3>Teachers Course: <b><?php echo e($student->course); ?></b></h3>

</div>

 </div>
 <a href="/teachers/<?php echo e($student->id); ?>/edit"><i class="fa btn btn-sm btn-success fa-edit">Edit</i> </a>

 <?php if($student->blocked_at != ''): ?>
 <a href="/unblockteacher/<?php echo e($student->id); ?>" class="btn btn-warning btn-sm">Unblock Teacher</a>

                   <?php else: ?>
                                     <a href="/blockteacher/<?php echo e($student->id); ?>" class="btn btn-warning btn-sm">Block Teacher</a>

                   <?php endif; ?><?php echo Form::open(['action'=>['TeachersController@destroy',$student->id], 'method'=>'DELETE', 'class'=>'float-left mr-1 mb-3']); ?>

  <?php echo e(Form::hidden('method', 'DELETE')); ?>

  <?php echo e(Form::submit('Delete', ['class'=>['btn btn-danger btn-sm ', 'float-left','mb-4']])); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school\resources\views/teachers/show.blade.php ENDPATH**/ ?>
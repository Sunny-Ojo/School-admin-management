<?php $__env->startSection('title', 'Update Teachers profile'); ?>
  <?php $__env->startSection('content'); ?>
  <hr>



  <a href="/teachers" class="btn btn-secondary mb-1">Go Back</a>

  <h1 class="bg-dark text-white text-center p-2">Update <?php echo e($teacher->firstName. ' ' .$teacher->lastName); ?>'s Profile</h1>
<div class="row">
<div class="col-md-8 col-lg-8 offset-md-2">
 <?php echo Form::open(['action' => ['TeachersController@update', $teacher->id], 'method'=>'PUT', 'enctype'=>'multipart/form-data']); ?>

<div class="form-group mt-3">
<?php echo e(Form::label('firstName', 'First Name')); ?>

<?php echo e(Form::text('firstName', $teacher->firstName, ['class'=> 'form-control'])); ?>

</div>
<div class="form-group ">
<?php echo e(Form::label('lastName', 'Last Name')); ?>

<?php echo e(Form::text('lastName', $teacher->lastName, ['class'=> 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('dob', ' Date of Birth: ')); ?>

    <?php echo e(Form::date('dob', $teacher->dob, ['class'=>'form-control'])); ?>

  </div>

<div class="form-group ">
<?php echo e(Form::label('gender', 'Gender')); ?>

<?php echo e(Form::select('gender',['male'=> 'Male', 'female'=>'Female'] ,$teacher->gender ,['class'=> 'form-control'])); ?>

</div>
<div class="form-group ">
    <?php echo e(Form::label('homeAddress', 'Home Address ')); ?>

    <?php echo e(Form::text('homeAddress', $teacher->homeAddress, ['class'=> 'form-control'])); ?>

    </div>
    <div class="form-group ">
        <?php echo e(Form::label('fathersName', "Father's Name ")); ?>

        <?php echo e(Form::text('fathersName', $teacher->fathersName, ['class'=> 'form-control'])); ?>

        </div>
        <div class="form-group ">
            <?php echo e(Form::label('emailAddress', 'Email Address')); ?>

            <?php echo e(Form::email('emailAddress', $teacher->emailAddress, ['class'=> 'form-control'])); ?>

            </div>
            <div class="form-group ">
                               <small>upload your passport</small><br>
 <?php echo e(Form::file('passport', )); ?> <br>
                           <img class="mt-2" style="width:65px;height:50px" src="<?php echo e('/storage/passports/'.$teacher->passport); ?>" alt="teachers passport">
 </div>
        <div class="form-group ">
            <?php echo e(Form::label('phone', 'Phone Number ')); ?>

            <?php echo e(Form::text('phone', $teacher->phone, ['class'=> 'form-control'])); ?>

            </div>
        <div class="form-group ">
            <?php echo e(Form::label('password', 'Change your password ')); ?>

            <?php echo e(Form::password('password', ['class'=> 'form-control'], $teacher->password)); ?>

            </div>
            <?php echo e(Form::submit('Update', ['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school\resources\views/teachers/edit.blade.php ENDPATH**/ ?>
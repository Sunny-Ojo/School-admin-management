<?php $__env->startSection('title', 'Add a Student '); ?>
  <?php $__env->startSection('content'); ?>
  <hr>


  <a href="/students" class="btn btn-secondary mb-1">Go Back</a>

  <h1 class="bg-dark text-white text-center p-2">Add a new Student</h1>
<div class="row">
<div class="col-md-8 col-lg-8 offset-md-2">
              <?php echo Form::open(['action' => 'StudentsController@store', 'method' => 'POST', 'enctype'=> 'multipart/form-data']); ?>

<div class="form-group mt-3">
<?php echo e(Form::label('firstName', 'First Name')); ?>

<?php echo e(Form::text('firstName','', ['class'=> 'form-control'])); ?>

<?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<div class="form-group ">
<?php echo e(Form::label('lastName', 'Last Name')); ?>

<?php echo e(Form::text('lastName', '', ['class'=> 'form-control'])); ?>

<?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<div class="form-group ">
<?php echo e(Form::label('dob', 'Date of Birth ')); ?>

<?php echo e(Form::date('dob', '', ['class'=> 'form-control'])); ?>

<?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<div class="form-group ">
<?php echo e(Form::label('gender', 'Gender')); ?>

<?php echo e(Form::select('gender',['male'=> 'Male', 'female'=>'Female'] ,'',['class'=> 'form-control'])); ?>

<?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
<div class="form-group ">
    <?php echo e(Form::label('homeAddress', 'Home Address ')); ?>

    <?php echo e(Form::text('homeAddress', '', ['class'=> 'form-control'])); ?>

    <?php $__errorArgs = ['homeAddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

</div>
    <div class="form-group ">
        <?php echo e(Form::label('fathersName', "Father's Name ")); ?>

        <?php echo e(Form::text('fathersName', '', ['class'=> 'form-control'])); ?>

        <?php $__errorArgs = ['fathersName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
        <div class="form-group ">
            <?php echo e(Form::label('emailAddress', 'Email Address')); ?>

            <?php echo e(Form::email('emailAddress', '', ['class'=> 'form-control'])); ?>

            <?php $__errorArgs = ['emailAddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
            <div class="form-group ">
                               <small>upload your passport</small><br>
 <?php echo e(Form::file('passport', )); ?> <br>
 <?php $__errorArgs = ['passport'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
 </div>
        <div class="form-group ">
            <?php echo e(Form::label('phone', 'Phone Number ')); ?>

            <?php echo e(Form::text('phone','', ['class'=> 'form-control'])); ?>


        </div>
        <div class="form-group ">
            <?php echo e(Form::label('course', 'Students Course ')); ?>

            <?php echo e(Form::text('course', '', ['class'=> 'form-control'])); ?>

                      <?php $__errorArgs = ['course'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <li class="text-danger"> <?php echo e($message); ?></li> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
            <?php echo e(Form::Submit('Create', ['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school\resources\views/students/create.blade.php ENDPATH**/ ?>
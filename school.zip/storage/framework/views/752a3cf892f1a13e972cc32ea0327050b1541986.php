<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\school\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
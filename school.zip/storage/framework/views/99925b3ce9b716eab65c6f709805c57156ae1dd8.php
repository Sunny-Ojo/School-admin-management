<?php $__env->startSection('title', 'Add a Student '); ?>
  <?php $__env->startSection('content'); ?>
  <hr>


  <a href="/teachersadmin" class="btn btn-secondary mb-1">Go Back</a>

  <h1 class="bg-dark text-white text-center p-2">Block this student</h1>
<div class="row">
<div class="col-md-8 col-lg-8 offset-md-2">
<form action="<?php echo e(route('blockedstudent')); ?>/<?php echo e($block->id); ?>" method="post" enctype="multipart/form-data"></form>
<div class="form-group mt-3">
<?php echo e(Form::label('firstName', 'First Name')); ?>

<?php echo e(Form::text('firstName',$block->firstName, ['class'=> 'form-control',  'placeholder' => 'Enter firstName'])); ?>


</div>
<div class="form-group ">
<?php echo e(Form::label('lastName', 'Last Name')); ?>

<?php echo e(Form::text('lastName', $block->lastName, ['class'=> 'form-control', 'placeholder' => 'Enter last name'])); ?>


</div>
<div class="form-group ">
<?php echo e(Form::label('reason', 'Reason to block student ')); ?>

<?php echo e(Form::text('reason', '', ['class'=> 'form-control', 'placeholder' => 'Enter Reason'])); ?>

</div>
<div class="form-group ">
<?php echo e(Form::hidden('passport', $block->passport)); ?>

</div>

            <?php echo e(Form::submit('Block', ['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\school\resources\views/teachersadmin/blockreason.blade.php ENDPATH**/ ?>